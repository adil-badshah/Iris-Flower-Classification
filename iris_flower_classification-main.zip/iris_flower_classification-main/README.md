# iris_flower_classification
predicting the species of the iris flowers based on sepal length, sepal width, petal length, petal width  (SVM model)
